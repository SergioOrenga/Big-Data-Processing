package io.keepcoding.spark.exercise.streaming

import java.sql.Timestamp
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

import org.apache.spark.sql.{DataFrame, SparkSession}

case class AntennaMessage(timestamp: Timestamp, id: String, antenna_id: String, bytes: Long, app: String)

trait StreamingJob {

  val spark: SparkSession

  def readFromKafka(kafkaServer: String, topic: String): DataFrame

  def parserJsonData(dataFrame: DataFrame): DataFrame

  def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame

  def enrichAntennaWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame

  def computeReceivedBytesByAntenna(dataFrame: DataFrame): DataFrame

  def computeTransmittedBytesByUserId(dataFrame: DataFrame): DataFrame

  def computeTransmittedBytesByApp(dataFrame: DataFrame): DataFrame

  def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit]

  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit]

  def run(args: Array[String]): Unit = {
    //Se definen los argumentos de entrada que se tienen que introducir y el orden en el que se tienen que introducir para ejecutar el job
    val Array(kafkaServer, topic, jdbcUri, jdbcMetadataTable, aggJdbcTable, jdbcUser, jdbcPassword, storagePath) = args
    println(s"Running with: ${args.toSeq}")

    //Se encadenan todos los métodos junto con los argumentos que se les pasan para que se ejecuten correctamente y así obtener la información requerida para cada uno de ellos
    val kafkaDF = readFromKafka(kafkaServer, topic)
    val antennaDF = parserJsonData(kafkaDF)
    val metadataDF = readAntennaMetadata(jdbcUri, jdbcMetadataTable, jdbcUser, jdbcPassword)
    val antennaMetadataDF = enrichAntennaWithMetadata(antennaDF, metadataDF)
    val storageFuture = writeToStorage(antennaDF, storagePath)
    val aggByAntennaDF = computeReceivedBytesByAntenna(antennaMetadataDF)
    val aggByUserIdDF = computeTransmittedBytesByUserId(antennaMetadataDF)
    val aggByAppDF = computeTransmittedBytesByApp(antennaMetadataDF)
    val aggFutureByAntenna = writeToJdbc(aggByAntennaDF, jdbcUri, aggJdbcTable, jdbcUser, jdbcPassword)
    val aggFutureByUserId = writeToJdbc(aggByUserIdDF, jdbcUri, aggJdbcTable, jdbcUser, jdbcPassword)
    val aggFutureByApp = writeToJdbc(aggByAppDF, jdbcUri, aggJdbcTable, jdbcUser, jdbcPassword)

    //Espera por los cuatro futuros
    Await.result(Future.sequence(Seq(aggFutureByAntenna, aggFutureByUserId, aggFutureByApp, storageFuture)), Duration.Inf)

    spark.close()
  }

}
