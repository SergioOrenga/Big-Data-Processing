package io.keepcoding.spark.exercise.batch

import java.time.OffsetDateTime

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object AntennaBatchJob extends BatchJob {

  override val spark: SparkSession = SparkSession
    //Se configura el SparkSession
    .builder()
    .master("local[*]")
    .appName("Spark SQL KeepCoding Base")
    .getOrCreate()

  import spark.implicits._

  override def readFromStorage(storagePath: String, filterDate: OffsetDateTime): DataFrame = {
    //Se configura la lectura de los archivos en formato PARQUET almacenados en el storage local
    //Dichos archivos están particionados por año, mes, día y hora
    spark
      .read
      .format("parquet")
      .load(s"${storagePath}/data")
      .filter(
        $"year" === filterDate.getYear &&
          $"month" === filterDate.getMonthValue &&
          $"day" === filterDate.getDayOfMonth &&
          $"hour" === filterDate.getHour
      )
  }

  override def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    //Lee los datos JDBC desde la tabla user_metadata de la base de datos postgreSQL de Google Cloud
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }

  override def enrichAntennaWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    //Se hace un join del dataframe de antenas y dispositivos móviles con el dataframe de metadatos de usuarios
    //mediante el campo id para completar la información adquirida en tiempo real con la almacenada en la
    //base de datos acerca de los metadatos de los usuarios
    antennaDF.as("antenna")
      .join(
        metadataDF.as("userMetadata"),
        $"antenna.id" === $"userMetadata.id"
      ).drop($"userMetadata.id")
  }

  override def computeReceivedBytesByAntennaHourly(dataFrame: DataFrame): DataFrame = {
    //Se realiza un agregado en una consulta para obtener los bytes totales recibidos por antena en cada hora
    //Se agrupan todos los eventos recibidos de cada hora
    //Se realiza la agregación de los datos, que en este caso es una suma de los valores del campo 'bytes'
    //Se almacenan los resultados en la tabla 'bytes_hourly' de PostgreSQL con el valor del campo 'type' como 'antenna_total_bytes'
    dataFrame
      .select($"timestamp", $"antenna_id", $"bytes")
      .groupBy(window($"timestamp", "1 hour"), $"antenna_id")
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"antenna_id".as("id"), $"value", lit("antenna_total_bytes").as("type"))
  }

  override def computeTransmittedBytesByUserMailHourly(dataFrame: DataFrame): DataFrame = {
    //Se realiza un agregado en una consulta para obtener los bytes totales transmitidos por id de usuario en cada hora
    //Se agrupan todos los eventos recibidos de cada hora
    //Se realiza la agregación de los datos, que en este caso es una suma de los valores del campo 'bytes'
    //Se almacenan los resultados en la tabla 'bytes_hourly' de PostgreSQL con el valor del campo 'type' como 'user_total_bytes'
    dataFrame
      .select($"timestamp", $"email", $"bytes")
      .groupBy(window($"timestamp", "1 hour"), $"email")
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"email".as("id"), $"value", lit("user_total_bytes").as("type"))
  }

  override def computeTransmittedBytesByAppHourly(dataFrame: DataFrame): DataFrame = {
    //Se realiza un agregado en una consulta para obtener los bytes totales transmitidos por aplicación en cada hora
    //Se agrupan todos los eventos recibidos de cada hora
    //Se realiza la agregación de los datos, que en este caso es una suma de los valores del campo 'bytes'
    //Se almacenan los resultados en la tabla 'bytes_hourly' de PostgreSQL con el valor del campo 'type' como 'app_total_bytes'
    dataFrame
      .select($"timestamp", $"app", $"bytes")
      .groupBy(window($"timestamp", "1 hour"), $"app")
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"app".as("id"), $"value", lit("app_total_bytes").as("type"))
  }

  override def computeUserQuotaLimitByUserMailHourly(dataFrame: DataFrame): DataFrame = {
    //Se realiza un agregado en una consulta para obtener los bytes totales transmitidos por e-mail de usuario en cada hora
    //Se agrupan todos los eventos recibidos de cada hora
    //Se realiza la agregación de los datos, que en este caso es una suma de los valores del campo 'bytes' y se guardan como el campo 'usage'
    //Se filtran los datos para quedarse sólo con aquellos registros en los que el valor del campo 'usage' es mayor que el valor del campo 'quota'
    //Se almacenan los resultados en la tabla 'user_quota_limit' de PostgreSQL
    dataFrame
      .select($"timestamp", $"email", $"bytes", $"quota")
      .groupBy(window($"timestamp", "1 hour"), $"email", $"quota")
      .agg(sum($"bytes").as("usage"))
      .select($"email", $"usage", $"quota", $"window.start".as("timestamp"))
      .where($"quota" < $"usage")
  }

  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit = {
    //Escribe a JDBC en las tablas de la base de datos PostgreSQL
    //La escritura se realiza en modo append, por lo que sólo se envian los registros nuevos añadidos desde
    //el último trigger, ya que los registros antiguos no se van a modificar
    dataFrame
      .write
      .mode(SaveMode.Append)
      .format("jdbc")
      .option("driver", "org.postgresql.Driver")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .save()
  }

  override def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Unit = {
    //Escribe en el storage el dataframe leído, sobreescribiendo el que había anteriormente
    //Se almacenan en formato PARQUET particionados por año, mes, día y hora
    //Se hace un coalesce de 1 para que los datos se compriman en un único archivo
    dataFrame
      .coalesce(1)
      .write
      .partitionBy("year", "month", "day", "hour")
      .format("parquet")
      .mode(SaveMode.Overwrite)
      .save(s"${storageRootPath}/historical")
  }

  def main(args: Array[String]): Unit = run(args)
}
