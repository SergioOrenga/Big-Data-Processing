package io.keepcoding.spark.exercise.batch

import java.sql.Timestamp
import java.time.OffsetDateTime
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

import org.apache.spark.sql.{DataFrame, SparkSession}

case class AntennaMessage(year: Int, month: Int, day: Int, hour: Int, timestamp: Timestamp, id: String, antenna_id: String, bytes: Long, app: String)

trait BatchJob {

  val spark: SparkSession

  def readFromStorage(storagePath: String, filterDate: OffsetDateTime): DataFrame

  def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame

  def enrichAntennaWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame

  def computeReceivedBytesByAntennaHourly(dataFrame: DataFrame): DataFrame

  def computeTransmittedBytesByUserMailHourly(dataFrame: DataFrame): DataFrame

  def computeTransmittedBytesByAppHourly(dataFrame: DataFrame): DataFrame

  def computeUserQuotaLimitByUserMailHourly(dataFrame: DataFrame): DataFrame

  def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit

  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Unit

  def run(args: Array[String]): Unit = {
    //Se definen los argumentos de entrada que se tienen que introducir y el orden en el que se tienen que introducir para ejecutar el job
    val Array(filterDate, storagePath, jdbcUri, jdbcUserMetadataTable, aggJdbcBytesHourlyTable, aggJdbcQuotaTable, jdbcUser, jdbcPassword) = args
    println(s"Running with: ${args.toSeq}")

    //Se encadenan todos los métodos junto con los argumentos que se les pasan para que se ejecuten correctamente y así obtener la información requerida para cada uno de ellos
    val antennaDF = readFromStorage(storagePath, OffsetDateTime.parse(filterDate))
    val metadataDF = readAntennaMetadata(jdbcUri, jdbcUserMetadataTable, jdbcUser, jdbcPassword)
    val antennaMetadataDF = enrichAntennaWithMetadata(antennaDF, metadataDF).cache()
    val aggByAntennaHourlyDF = computeReceivedBytesByAntennaHourly(antennaMetadataDF)
    val aggByUserMailHourlyDF = computeTransmittedBytesByUserMailHourly(antennaMetadataDF)
    val aggByAppHourlyDF = computeTransmittedBytesByAppHourly(antennaMetadataDF)
    val aggQuotaLimitByUserMailHourlyDF = computeUserQuotaLimitByUserMailHourly(antennaMetadataDF)

    writeToJdbc(aggByAntennaHourlyDF, jdbcUri, aggJdbcBytesHourlyTable, jdbcUser, jdbcPassword)
    writeToJdbc(aggByUserMailHourlyDF, jdbcUri, aggJdbcBytesHourlyTable, jdbcUser, jdbcPassword)
    writeToJdbc(aggByAppHourlyDF, jdbcUri, aggJdbcBytesHourlyTable, jdbcUser, jdbcPassword)
    writeToJdbc(aggQuotaLimitByUserMailHourlyDF, jdbcUri, aggJdbcQuotaTable, jdbcUser, jdbcPassword)

    writeToStorage(antennaDF, storagePath)

    spark.close()
  }

}
