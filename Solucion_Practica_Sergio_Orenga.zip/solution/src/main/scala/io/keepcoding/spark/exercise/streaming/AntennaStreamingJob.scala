package io.keepcoding.spark.exercise.streaming

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructType, TimestampType}

object AntennaStreamingJob extends StreamingJob {

  override val spark: SparkSession = SparkSession
    //Se configura el SparkSession
    .builder()
    .master("local[20]")
    .appName("Spark SQL KeepCoding Base")
    .getOrCreate()

  import spark.implicits._

  override def readFromKafka(kafkaServer: String, topic: String): DataFrame = {
    //Se configura la lectura desde Kafka
    spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("subscribe", topic)
      .load()
  }

  override def parserJsonData(dataFrame: DataFrame): DataFrame = {
    //Se configura el parseo del Json, al que se le pasa el DataFrame que se ha leído de kafka
    //Se define el esquema para que coja automáticamente la estructura de campos del esquema, de esa forma no hace
    //falta definirlos individualemente
    val antennaMessageSchema: StructType = ScalaReflection.schemaFor[AntennaMessage].dataType.asInstanceOf[StructType]
    dataFrame
      .select(from_json(col("value").cast(StringType), antennaMessageSchema).as("json"))
      .select("json.*")
      .withColumn("timestamp", $"timestamp".cast(TimestampType))
  }

  override def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    //Lee los datos JDBC desde la tabla user_metadata de la base de datos postgreSQL de Google Cloud
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }

  override def enrichAntennaWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    //Se hace un join del dataframe de antenas y dispositivos móviles con el dataframe de metadatos de usuarios
    //mediante el campo id para completar la información adquirida en tiempo real con la almacenada en la
    //base de datos acerca de los metadatos de los usuarios
    antennaDF.as("antenna")
      .join(
        metadataDF.as("userMetadata"),
        $"antenna.id" === $"userMetadata.id"
      ).drop($"userMetadata.id")
  }

  override def computeReceivedBytesByAntenna(dataFrame: DataFrame): DataFrame = {
    //Se realiza un agregado en una consulta para obtener los bytes totales recibidos por antena
    //Se establece un watermark de un minuto, por lo que no se contabilizarán los eventos con más de un minuto de retraso
    //Se agrupan todos los eventos recibidos de cada 5 minutos
    //Se realiza la agregación de los datos, que en este caso es una suma de los valores del campo 'bytes'
    //Se almacenan los resultados en la tabla 'bytes' de PostgreSQL con el valor del campo 'type' como 'antenna_total_bytes'
    dataFrame
      .select($"timestamp", $"antenna_id", $"bytes")
      .withWatermark("timestamp", "1 minute")
      .groupBy($"antenna_id", window($"timestamp", "5 minutes"))
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"antenna_id".as("id"), $"value", lit("antenna_total_bytes").as("type"))
  }

  override def computeTransmittedBytesByUserId(dataFrame: DataFrame): DataFrame = {
    //Se realiza un agregado en una consulta para obtener los bytes totales transmitidos por id de usuario
    //Se establece un watermark de un minuto, por lo que no se contabilizarán los eventos con más de un minuto de retraso
    //Se agrupan todos los eventos recibidos de cada 5 minutos
    //Se realiza la agregación de los datos, que en este caso es una suma de los valores del campo 'bytes'
    //Se almacenan los resultados en la tabla 'bytes' de PostgreSQL con el valor del campo 'type' como 'user_total_bytes'
    dataFrame
      .select($"timestamp", $"id", $"bytes")
      .withWatermark("timestamp", "1 minute")
      .groupBy($"id", window($"timestamp", "5 minutes"))
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"id", $"value", lit("user_total_bytes").as("type"))
  }

  override def computeTransmittedBytesByApp(dataFrame: DataFrame): DataFrame = {
    //Se realiza un agregado en una consulta para obtener los bytes totales transmitidos por aplicación
    //Se establece un watermark de un minuto, por lo que no se contabilizarán los eventos con más de un minuto de retraso
    //Se agrupan todos los eventos recibidos de cada 5 minutos
    //Se realiza la agregación de los datos, que en este caso es una suma de los valores del campo 'bytes'
    //Se almacenan los resultados en la tabla 'bytes' de PostgreSQL con el valor del campo 'type' como 'app_total_bytes'
    dataFrame
      .select($"timestamp", $"app", $"bytes")
      .withWatermark("timestamp", "1 minute")
      .groupBy($"app", window($"timestamp", "5 minutes"))
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"app".as("id"), $"value", lit("app_total_bytes").as("type"))
  }

  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit] = Future {
    //Escribe a JDBC en las tablas de la base de datos PostgreSQL
    //Se ejecuta dentro de un futuro porque se tienen que hacer dos tareas en paralelo, que son
    //escribir a JDBC y escribir en el storage en formato PARQUET
    dataFrame
      .writeStream
      //En el Stream se itera en cada Batch, por lo que ya podemos trabajar con un dataframe de batch y no con un dataframe de stream
      //Por cada batch del stream devuelve el batch y el id del batch. Esto se hace para poder realizar
      //un write normal de JDBC en las tablas de la base de datos PostgreSQL
      //La escritura se realiza en modo append, por lo que sólo se envian los registros nuevos añadidos desde
      //el último trigger, ya que los registros antiguos no se van a modificar
      .foreachBatch { (data: DataFrame, batchId: Long) =>
        data
          .write
          .mode(SaveMode.Append)
          .format("jdbc")
          .option("driver", "org.postgresql.Driver")
          .option("url", jdbcURI)
          .option("dbtable", jdbcTable)
          .option("user", user)
          .option("password", password)
          .save()
      }
      .start()
      .awaitTermination()
  }

  override def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit] = Future {
    //Escribe en el storage el dataframe original para poder realizar en el job de batch los joins necesarios
    //Se almacenan en formato PARQUET particionados por año, mes, día y hora
    //Se ejecuta en un futuro junto con el método de escribir a JDBC
    val columns = dataFrame.columns.map(col).toSeq ++
      Seq(
        year($"timestamp").as("year"),
        month($"timestamp").as("month"),
        dayofmonth($"timestamp").as("day"),
        hour($"timestamp").as("hour")
      )

    dataFrame
      .select(columns: _*)
      .writeStream
      .partitionBy("year", "month", "day", "hour")
      .format("parquet")
      .option("path", s"${storageRootPath}/data")
      .option("checkpointLocation", s"${storageRootPath}/checkpoint")
      .start()
      .awaitTermination()
  }

  def main(args: Array[String]): Unit = run(args)
}
